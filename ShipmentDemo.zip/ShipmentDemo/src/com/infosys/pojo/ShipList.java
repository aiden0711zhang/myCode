package com.infosys.pojo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ShipList implements Serializable {

	private static final long serialVersionUID = 6400475437153194477L;

	private ShipList() {
		shipList = new ArrayList<Ship>();
		Ship ship1 = new Ship("Ship No. 1", 40, 0, 40,new ArrayList<Goods>());
		shipList.add(ship1);
		Ship ship2 = new Ship("Ship No. 2", 60, 0, 60,new ArrayList<Goods>());
		shipList.add(ship2);
		Ship ship3 = new Ship("Ship No. 1", 100, 0, 100,new ArrayList<Goods>());
		shipList.add(ship3);
	}

	private List<Ship> shipList;

	private static ShipList instance;

	public synchronized static ShipList getInstance() {
		if (null == instance) {
			instance = new ShipList();
		}

		return instance;
	}

	public List<Ship> getShipList() {
		return shipList;
	}

}
