package com.infosys.business;

import com.infosys.pojo.Goods;
import com.infosys.pojo.Order;

public interface Shipment {

	/**
	 * 货物拆分---split
	 * @param order
	 * @param goods
	 */
	void split(Order order,Goods goods);
	/**
	 * 货物合并---merge
	 * @param order
	 * @param goodsArr
	 */
	void merge(Order order,Goods... goodsArr);
	
}
