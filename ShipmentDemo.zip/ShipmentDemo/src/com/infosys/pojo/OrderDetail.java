package com.infosys.pojo;

import java.io.Serializable;

public class OrderDetail implements Serializable {

	private static final long serialVersionUID = -843157263368307529L;
	private int orderNo;
	private Ship[] ships;

	
	public OrderDetail() {
		super();
	}

	public int getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}

	public Ship[] getShips() {
		return ships;
	}

	public void setShips(Ship[] ships) {
		this.ships = ships;
	}
}
