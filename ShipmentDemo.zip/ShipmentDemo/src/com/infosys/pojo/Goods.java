package com.infosys.pojo;

import java.io.Serializable;

public class Goods implements Serializable,Comparable<Goods> {

	private static final long serialVersionUID = -7695286769894726212L;
	private int goodsId;
	private String goodsName;
	private int orderId;
	private double weight;
	public Goods() {
		super();
	}
	public int getGoodsId() {
		return goodsId;
	}
	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	@Override
	public int compareTo(Goods arg0) {
		// TODO Auto-generated method stub
		return this.goodsId-arg0.goodsId;
	}
	@Override
	public String toString() {
		return "{goodsId:" + goodsId + ", goodsName:" + goodsName + ", orderId:" + orderId + ", weight:" + weight
				+ "}";
	}
	
	
	
}
