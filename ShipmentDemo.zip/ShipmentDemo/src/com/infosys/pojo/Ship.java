package com.infosys.pojo;

import java.io.Serializable;
import java.util.List;

public class Ship implements Serializable {

	private static final long serialVersionUID = 7162007277643377714L;
	private String shipNo;
	private int capcity;
	private int goodsLoaded;
	private int freeDeadWeight;
	private List<Goods> carryGoods;
	
	public Ship() {
		super();
	}

	
	public Ship(String shipNo, int capcity, int goodsLoaded, int freeDeadWeight,List<Goods> carryGoods) {
		super();
		this.shipNo = shipNo;
		this.capcity = capcity;
		this.goodsLoaded = goodsLoaded;
		this.freeDeadWeight = freeDeadWeight;
		this.carryGoods = carryGoods;
	}


	public String getShipNo() {
		return shipNo;
	}

	public void setShipNo(String shipNo) {
		this.shipNo = shipNo;
	}

	public int getCapcity() {
		return capcity;
	}

	public void setCapcity(int capcity) {
		this.capcity = capcity;
	}

	public int getGoodsLoaded() {
		return goodsLoaded;
	}

	public void setGoodsLoaded(int goodsLoaded) {
		this.goodsLoaded = goodsLoaded;
	}

	public int getFreeDeadWeight() {
		return freeDeadWeight;
	}

	public void setFreeDeadWeight(int freeDeadWeight) {
		this.freeDeadWeight = freeDeadWeight;
	}


	public List<Goods> getCarryGoods() {
		return carryGoods;
	}


	public void setCarryGoods(List<Goods> carryGoods) {
		this.carryGoods = carryGoods;
	}

}
