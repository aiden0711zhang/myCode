package com.infosys.business;

import java.util.ArrayList;
import java.util.List;

import com.infosys.pojo.Goods;
import com.infosys.pojo.Order;

public class ShipmentImpl implements Shipment {
	//可实现配置化，拆分比例之和为1.测试需要修饰为public
	public String splitRule;

	@Override
	public void split(Order order, Goods goods) {
		if(order.getOrderNo() != goods.getOrderId()) {
			return;
		}
		// 
		if(null != splitRule && !"".equals(splitRule)) {
			String[] percentNums = splitRule.split(":");
			double goodsQuantity = goods.getWeight();
			
			
			List<Goods> goodsList = new ArrayList<Goods>();
			double total = 0;
			double preTotal = 0;
			double sum = 0;
			for(int i=0;i<percentNums.length;i++) {
				sum += Double.valueOf(percentNums[i]);
				
				Goods childGoods = new Goods();
				childGoods.setGoodsId(goods.getGoodsId());
				childGoods.setGoodsName(goods.getGoodsName());
				childGoods.setOrderId(goods.getOrderId());
				double childWeight = Math.round(goodsQuantity*Double.valueOf(percentNums[i]));
				total += childWeight;
				if(i==percentNums.length-1 && total!=goodsQuantity) {
					if(sum>1) {
						throw new RuntimeException("拆分比例数据异常，拆分比例之和为1");
					}
					childWeight = goodsQuantity-preTotal;
				}
				childGoods.setWeight(childWeight);
				goodsList.add(childGoods);
				preTotal = total;
				
			}
			//update Order 's childList
			setChildList(order,goods,goodsList);
			
			order.setShipCounter(order.getShipCounter()+percentNums.length);
			
			//TODO update order  in the DB
			
		}

	}

	private void setChildList(Order order,Goods goods, List<Goods> goodsList) {
		// 
		List<Goods> childList = order.getChildList();
		
		if(childList==null) {
			childList = new ArrayList<Goods>();
		}
		for(Goods child:childList) {
			if(child.equals(goods)) {
				childList.remove(child);
				break;
			}
		}
		childList.addAll(goodsList);
		order.setChildList(childList);
		
	}

	@Override
	public void merge(Order order, Goods... goodsArr) {
		// 先判断所有要合并项均为一个order的拆分子项
		Goods[] goodsArray = goodsArr;
		isInChildList(order,goodsArray);
		
		List<Goods> childList = order.getChildList();
		double total = 0;
		Goods goodsAfterMerge = new Goods();
		goodsAfterMerge.setGoodsId(goodsArray[0].getGoodsId());
		goodsAfterMerge.setGoodsName(goodsArray[0].getGoodsName());
		goodsAfterMerge.setOrderId(order.getOrderNo());
		
		for(int i=0;i<goodsArray.length;i++) {
			total += goodsArray[i].getWeight();
			childList.remove(goodsArray[i]);
		}
		goodsAfterMerge.setWeight(total);
		
		childList.add(goodsAfterMerge);
		order.setChildList(childList);
		order.setShipCounter(order.getShipCounter()+1);
		
		//TODO update order  in the DB

	}

	private void isInChildList(Order order,Goods[] goodsArray) {
		
		for(int i=0;i<goodsArray.length;i++) {
			Goods goods = goodsArray[i];
			if(goods.getOrderId()!=order.getOrderNo() || !order.getChildList().contains(goods)) {
				throw new RuntimeException("数据异常");
			}
		}
	}

}
