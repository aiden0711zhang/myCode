package com.infosys.pojo;

import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {

	private static final long serialVersionUID = 6811657438204078802L;
	private int orderNo;
	private double orderQuantity;
	private int goodsId;
	private List<Goods> childList;
	private int shipCounter;

	
	public Order() {
		super();
	}


	public int getOrderNo() {
		return orderNo;
	}


	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}


	public double getOrderQuantity() {
		return orderQuantity;
	}


	public void setOrderQuantity(double orderQuantity) {
		this.orderQuantity = orderQuantity;
	}


	public List<Goods> getChildList() {
		return childList;
	}


	public void setChildList(List<Goods> childList) {
		this.childList = childList;
	}


	public int getShipCounter() {
		return shipCounter;
	}


	public void setShipCounter(int shipCounter) {
		this.shipCounter = shipCounter;
	}


	public int getGoodsId() {
		return goodsId;
	}


	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}


}
